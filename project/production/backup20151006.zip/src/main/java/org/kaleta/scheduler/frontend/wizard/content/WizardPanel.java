package org.kaleta.scheduler.frontend.wizard.content;

/**
 * Author: Stanislav Kaleta
 * Date: 1.8.2015
 *
 * TODO documentation
 */
public interface WizardPanel {

    /**
     * TODO documentation
     *
     * @return
     */
    public boolean isFilled();

    /**
     * TODO documentation
     *
     * @param flag
     */
    public void setVisible(boolean flag);
}
